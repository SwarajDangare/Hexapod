fh = open('Hexapod.xacro', 'rw')
l = fh.readline()